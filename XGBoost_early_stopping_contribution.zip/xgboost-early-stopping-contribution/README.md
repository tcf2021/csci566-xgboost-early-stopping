# Independent evaluation with XGBoost early stopping

A focused, AI-assisted documentation contribution for CSCI 566. The patch separates
early-stopping validation from independent test evaluation in XGBoost's scikit-learn
interface guide. It changes one documentation file, not XGBoost's training code or API.

## Contribution

- Reserve a final test partition before splitting development data into training and validation.
- Use validation, not test data, in the early-stopping and callback examples.
- Within each cross-validation outer training fold, create an inner validation partition.
- Score the untouched outer fold only after the stopping iteration has been selected.
- Explain the difference between fixed-procedure evaluation and using CV scores for tuning.

The original examples execute successfully. The issue is evaluation independence and
terminology, not a runtime failure. Two-way train/validation splitting remains valid for
training; a separate test set is needed when an independent final estimate is required.

Upstream: https://github.com/dmlc/xgboost

Pinned upstream commit: `293cad1a89ab749e3266e190c68118af2db09982`

Changed file: `doc/python/sklearn_estimator.rst` (44 insertions, 23 deletions).

The full difference is in `xgboost-early-stopping.patch`; `upstream/` preserves the original
document from the pinned commit. No upstream issue or PR has been opened for this work.

## Reproduce

Use Python 3.12 in a fresh environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/verify_examples.py
```

On Windows, activate with `.venv\Scripts\Activate.ps1` instead. The numerical checks use
only scikit-learn's bundled public dataset. They do not read personal or research data.
Successful execution prints `"status": "PASS"` and writes a new run under `evidence/rerun/`.

The recorded reference run used `xgboost-cpu==3.4.1` on Linux. The portable requirements
use `xgboost==3.4.1`, which may install larger platform dependencies. Record the actual
environment when reproducing; results are not a promise of bitwise portability.

To restore the exact upstream base and apply the patch in a new local Git checkout:

```bash
python scripts/restore_repo.py restored-xgboost
git -C restored-xgboost diff --check
```

The destination must not exist. The script downloads public source and creates a local
branch. It does not push or open a pull request.

## Verification and provenance

The contributor reports that local verification passed. No additional local environment,
command, or result logs were supplied for that statement. Detailed numerical evidence in
`evidence/assistant_run/` is from the separately recorded AI-assisted reference run.

Reference checks passed:

- All four revised RST code blocks execute in document order.
- Training, early-stopping validation, and scoring rows are disjoint in the introduction
  and every one of the five CV folds.
- Callback validation data is consistent with the introduction.
- For fixed outer-fold membership, changing test labels leaves the revised trained model
  byte-identical, while changing its score as expected.
- The original helper changes its selected stopping iteration under the same perturbation.
- The patch applies to the pinned base, and `git diff --check` passes.

An isolated Sphinx preview also built successfully. It is not the full upstream site build.
To reproduce that preview:

```bash
python -m pip install -r requirements-preview.txt
python scripts/build_preview.py
```

Not performed: XGBoost source compilation, GPU tests, the full upstream test suite,
the complete upstream documentation build, or public CI. Accuracy numbers are observations,
not evidence that the documentation change improves model accuracy.

## Report and attribution

The report uses the four required headings: Project and need, New work, Verification,
and Explanation. See `report/CSCI566_XGBoost_Contribution_Report.pdf`.

AI assisted the background research, patch and helper-script drafting, reference execution,
and report preparation. The contributor separately confirmed successful local verification.
See `review/AI_ASSISTANCE.md` and the report for the boundary between these sources.

Related work and the limits of the duplicate search are recorded in `review/PRIOR_WORK.md`.
No claim of maintainer acceptance or guaranteed course credit is made.

The XGBoost files retain their Apache-2.0 license; see `LICENSE-XGBoost`.
