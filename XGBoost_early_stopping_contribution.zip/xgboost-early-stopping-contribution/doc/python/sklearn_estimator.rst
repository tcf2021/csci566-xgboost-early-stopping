##########################################
Using the Scikit-Learn Estimator Interface
##########################################

**Contents**

.. contents::
  :backlinks: none
  :local:

********
Overview
********

In addition to the native interface, XGBoost features a sklearn estimator interface that
conforms to `sklearn estimator guideline
<https://scikit-learn.org/stable/developers/develop.html#rolling-your-own-estimator>`__. It
supports regression, classification, and learning to rank. Survival training for the
sklearn estimator interface is still working in progress.

You can find some some quick start examples at
:ref:`sphx_glr_python_examples_sklearn_examples.py`. The main advantage of using sklearn
interface is that it works with most of the utilities provided by sklearn like
:py:func:`sklearn.model_selection.cross_validate`. Also, many other libraries recognize
the sklearn estimator interface thanks to its popularity.

With the sklearn estimator interface, we can train a classification model and use a
validation set for early stopping. This example also reserves a separate test set for
evaluating the selected model:

.. code-block:: python

    from sklearn.datasets import load_breast_cancer
    from sklearn.model_selection import train_test_split

    import xgboost as xgb

    X, y = load_breast_cancer(return_X_y=True)
    # Keep the final test set out of training and early stopping.
    X_dev, X_test, y_dev, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=94
    )
    X_train, X_valid, y_train, y_valid = train_test_split(
        X_dev, y_dev, test_size=0.25, stratify=y_dev, random_state=94
    )

    # Use "hist" for constructing the trees, with early stopping enabled.
    clf = xgb.XGBClassifier(tree_method="hist", early_stopping_rounds=2)
    # Fit on training data; select the stopping iteration on validation data.
    clf.fit(X_train, y_train, eval_set=[(X_valid, y_valid)])
    # Evaluate the selected model on the untouched test set.
    print(clf.score(X_test, y_test))
    # Save model into JSON format.
    clf.save_model("clf.json")


The ``tree_method`` parameter specifies the method to use for constructing the trees, and
the early_stopping_rounds parameter enables early stopping. Early stopping can help
prevent overfitting and save time during training.

Early stopping uses validation labels to select the number of boosting rounds. Its
validation score is therefore not an independent final performance estimate. Keep the
test set out of ``eval_set`` and other model-selection decisions, and evaluate it only
after those decisions are complete. The split proportions above are illustrative; the
appropriate splitting strategy depends on the data.

**************
Early Stopping
**************

As demonstrated in the previous example, early stopping can be enabled by the parameter
``early_stopping_rounds``. Alternatively, there's a callback function that can be used
:py:class:`xgboost.callback.EarlyStopping` to specify more details about the behavior of
early stopping, including whether XGBoost should return the best model instead of the full
stack of trees:

.. code-block:: python

    early_stop = xgb.callback.EarlyStopping(
        rounds=2, metric_name='logloss', data_name='validation_0', save_best=True
    )
    clf = xgb.XGBClassifier(tree_method="hist", callbacks=[early_stop])
    clf.fit(X_train, y_train, eval_set=[(X_valid, y_valid)])

At present, XGBoost doesn't implement data splitting logic within the estimator and relies
on the ``eval_set`` parameter of the :py:meth:`xgboost.XGBModel.fit` method. If you want
to use early stopping to prevent overfitting, you'll need to manually split your data into
training and validation sets using the :py:func:`sklearn.model_selection.train_test_split`
function from the `sklearn` library. Reserve separate data if you also need an independent
final evaluation.

For cross validation, split each outer training fold again to obtain an early-stopping
validation set. Use the outer test fold only for scoring, not for choosing the stopping
iteration. Different folds can select different numbers of trees; each outer score
evaluates the same training procedure on different data. The following example uses
fixed hyperparameters. If you use cross-validation results to select hyperparameters,
those results are model-selection scores; a further held-out test set or nested cross
validation is needed for an independent final evaluation.

.. code-block:: python

    from sklearn.base import clone
    from sklearn.datasets import load_breast_cancer
    from sklearn.model_selection import StratifiedKFold, train_test_split

    import xgboost as xgb

    X, y = load_breast_cancer(return_X_y=True)


    def fit_and_score(estimator, X_dev, X_test, y_dev, y_test):
        """Select the stopping iteration without using the outer test fold."""
        X_train, X_valid, y_train, y_valid = train_test_split(
            X_dev, y_dev, test_size=0.2, stratify=y_dev, random_state=94
        )
        estimator.fit(X_train, y_train, eval_set=[(X_valid, y_valid)])

        train_score = estimator.score(X_train, y_train)
        test_score = estimator.score(X_test, y_test)

        return estimator, train_score, test_score


    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=94)

    estimator = xgb.XGBClassifier(tree_method="hist", early_stopping_rounds=3)

    results = {}

    for development, test in cv.split(X, y):
        X_dev = X[development]
        X_test = X[test]
        y_dev = y[development]
        y_test = y[test]
        est, train_score, test_score = fit_and_score(
            clone(estimator), X_dev, X_test, y_dev, y_test
        )
        results[est] = (train_score, test_score)


***********************************
Obtaining the native booster object
***********************************

The sklearn estimator interface primarily facilitates training and doesn't implement all
features available in XGBoost. For instance, in order to have cached predictions,
:py:class:`xgboost.DMatrix` needs to be used with :py:meth:`xgboost.Booster.predict`. One
can obtain the booster object from the sklearn interface using
:py:meth:`xgboost.XGBModel.get_booster`:

.. code-block:: python

   booster = clf.get_booster()
   print(booster.num_boosted_rounds())


**********
Prediction
**********

When early stopping is enabled, prediction functions including the
:py:meth:`xgboost.XGBModel.predict`, :py:meth:`xgboost.XGBModel.score`, and
:py:meth:`xgboost.XGBModel.apply` methods will use the best model automatically. Meaning
the :py:attr:`xgboost.XGBModel.best_iteration` is used to specify the range of trees used
in prediction.

To have cached results for incremental prediction, please use the
:py:meth:`xgboost.Booster.predict` method instead.


**************************
Number of parallel threads
**************************

When working with XGBoost and other sklearn tools, you can specify how many threads you
want to use by using the ``n_jobs`` parameter. By default, XGBoost uses all the available
threads on your computer, which can lead to some interesting consequences when combined
with other sklearn functions like :py:func:`sklearn.model_selection.cross_validate`. If
both XGBoost and sklearn are set to use all threads, your computer may start to slow down
significantly due to something called "thread thrashing". To avoid this, you can simply
set the ``n_jobs`` parameter for XGBoost to `None` (which uses all threads) and the
``n_jobs`` parameter for sklearn to `1`. This way, both programs will be able to work
together smoothly without causing any unnecessary computer strain.
