# Build the report

- `report.tex`: editable LaTeX source.
- `CSCI566_XGBoost_Contribution_Report.pdf`: compiled three-page report (the `report.pdf` output, renamed for distribution).
- `report.md`: matching editable text.
- `template.tex`: layout used when converting Markdown to LaTeX.

With TeX Live installed, compile the LaTeX source twice:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The document uses Latin Modern fonts and the geometry, microtype, xcolor,
booktabs, longtable, array, calc, etoolbox, fancyvrb, fvextra, fancyhdr,
titlesec, xurl, and hyperref packages.

To regenerate the LaTeX after editing Markdown, run:

```sh
pandoc report.md --from markdown --to latex --standalone \
  --template template.tex --no-highlight --number-sections -o report.tex
```

Then compile twice. If editing LaTeX directly, keep the Markdown in sync.

The PDF was compiled with pdfTeX 1.40.26 and checked by rendering all three
pages. No code experiments were rerun for this writing revision. Numerical
results remain those in the existing recorded reference evidence.
