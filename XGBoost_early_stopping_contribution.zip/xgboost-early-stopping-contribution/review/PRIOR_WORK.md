# 问题依据与已有工作

核查日期：2026-11-11。范围为当前官方文档、对应文件历史、针对主题的开放和关闭 issue/PR 搜索。
未找到完全相同的修复；该结论不代表穷尽全部讨论，也不是上游批准。

## 实际需求

固定版本的原文档：
https://github.com/dmlc/xgboost/blob/293cad1a89ab749e3266e190c68118af2db09982/doc/python/sklearn_estimator.rst

原入门例把用于 early stopping 的数据称作 test；原 CV helper 在同一外层 held-out fold 上
选择停止轮次并计算 test_score。文档应区分选择模型用的 validation 与未参与选择的 test。
新例不引入自动切分 API，不改变 XGBoost 的训练实现。

## 相关、但不同的历史工作

- https://github.com/dmlc/xgboost/issues/7782 ：动态 eval_set / estimator 内部切分的功能请求。
  它不是本文档修复。维护者提及样本元数据、ranking、GPU 和分布式等复杂性，故保持显式切分。
- https://github.com/dmlc/xgboost/issues/7782#issuecomment-1104825533 ：上述设计顾虑。
- https://github.com/dmlc/xgboost/issues/7782#issuecomment-2886336833 ：pipeline 预处理之后内部切分可能泄漏的讨论。
- https://github.com/dmlc/xgboost/pull/8948 ：最初引入 sklearn guide。
- https://github.com/dmlc/xgboost/pull/9304 ：best_iteration 和 inference 的澄清，非评估独立性修复。
- https://github.com/dmlc/xgboost/pull/7334 ：early-stopping 属性数量的文档修正。
- 文件后续历史中的 #9458、#10023、#10058、#12401 为其他文档/拼写修正，没有解决本题的数据角色问题。

## 贡献规范

- https://github.com/dmlc/xgboost/blob/master/doc/contrib/index.rst 欢迎文档和用法示例贡献。
- https://github.com/dmlc/xgboost/blob/master/doc/contrib/docs.rst 说明 Sphinx/reStructuredText 和 `make html`。
  普通 code-block 并不由当前 doctest job 自动执行，因此本包直接运行真实代码块。
- 已查的贡献文件中未找到统一正式 AI 政策；这不意味着未来不会变化。
  https://github.com/dmlc/xgboost/pull/11688#issuecomment-3301576507 中维护者允许 LLM 辅助，
  同时反对未经理解和验证的公开试验。公开前应再次核查最新规则。

## 再次查重建议

在仓库 issues 和 PRs 同时查 open / closed：
`sklearn_estimator`、`early stopping validation test`、`data leakage`、`cross validation`。
看相关评论、关联 PR、assignee 和近期修改。若已有完整等价修复，不重复发布。
