"""Build an isolated Sphinx preview of the exact revised RST.

This checks one page's RST rendering, not XGBoost's full documentation build.
Existing cross-reference targets outside this page are represented by a clearly
labelled reference page. API roles are parsed by Sphinx's standard Python domain.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory() as directory:
    source = Path(directory)
    shutil.copyfile(ROOT / 'doc/python/sklearn_estimator.rst', source / 'sklearn_estimator.rst')
    (source / 'conf.py').write_text(
        "project = 'XGBoost early-stopping page preview'\n"
        "extensions = []\nmaster_doc = 'index'\nhtml_theme = 'alabaster'\n"
        "html_show_sourcelink = False\n", encoding='utf-8')
    (source / 'index.rst').write_text(
        "Local documentation preview\n===========================\n\n"
        "This is an isolated preview, not the official XGBoost documentation site.\n"
        "Only the revised page is rendered; external reference targets are placeholders.\n\n"
        ".. toctree::\n   :maxdepth: 2\n\n   sklearn_estimator\n   reference_targets\n",
        encoding='utf-8')
    (source / 'reference_targets.rst').write_text(
        "Reference placeholders\n======================\n\n"
        "These labels allow standalone rendering. Use the official documentation\n"
        "for full reference content. This preview does not validate external links.\n\n"
        ".. _sphx_glr_python_examples_sklearn_examples.py:\n\n"
        "Example gallery\n---------------\n\n"
        "https://xgboost.readthedocs.io/en/stable/python/examples/sklearn_examples.html\n\n"
        ".. _callback_api:\n\nCallback API\n------------\n\n"
        "https://xgboost.readthedocs.io/en/stable/python/callbacks.html\n\n"
        ".. _py-data:\n\nSupported data\n--------------\n\n"
        "https://xgboost.readthedocs.io/en/stable/python/data_input.html\n",
        encoding='utf-8')
    subprocess.run([sys.executable, '-m', 'sphinx', '-W', '--keep-going',
                    '-b', 'html', str(source), str(ROOT / 'preview')], check=True)
