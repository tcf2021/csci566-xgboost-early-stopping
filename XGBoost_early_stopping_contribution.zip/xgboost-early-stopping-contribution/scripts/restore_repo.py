"""Create a fresh local, sparse XGBoost checkout and apply the supplied patch.

Only public source is downloaded. Nothing is pushed or published.
"""
import argparse
import hashlib
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path, help='A new directory that does not exist')
    args = parser.parse_args()
    target = args.destination.resolve()
    if target.exists():
        raise SystemExit('Destination already exists. Choose a new directory; nothing was changed.')
    commit = (ROOT / 'UPSTREAM_COMMIT.txt').read_text().strip()
    patch = ROOT / 'xgboost-early-stopping.patch'
    target.mkdir(parents=True)

    def git(*arguments):
        subprocess.run(['git', '-C', str(target), *arguments], check=True)

    git('init')
    git('remote', 'add', 'origin', 'https://github.com/dmlc/xgboost.git')
    git('fetch', '--depth=1', '--filter=blob:none', 'origin', commit)
    git('sparse-checkout', 'init', '--cone')
    git('sparse-checkout', 'set', 'doc', '.github')
    git('checkout', '-b', 'docs/independent-early-stopping-evaluation', 'FETCH_HEAD')
    git('apply', '--check', str(patch))
    git('apply', str(patch))
    git('diff', '--check')
    relative = Path('doc/python/sklearn_estimator.rst')
    actual = hashlib.sha256((target / relative).read_bytes()).hexdigest()
    expected = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit('Patched document differs from the reviewed copy. Inspect before continuing.')
    print(f'Local checkout ready: {target}')
    print(f'Pinned upstream commit: {commit}')
    print('No commit, push, pull request, or coursework submission was created.')


if __name__ == '__main__':
    main()
